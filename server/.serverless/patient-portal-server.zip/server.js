// encapulating into serverless
const serverless = require('serverless-http');

require("dotenv").config()
const express = require('express');
const app = express();

// setting up view engine and middleware
app.set('view engine', 'ejs');
app
  .use(logger)
  .use(express.static('public'))
  .use(express.urlencoded({extended: true})); 

function logger(req, res, next) {
  console.log(`Hitting: ${req.originalUrl}`);
  next();
}

// setting up default path
app.get('/', (req, res) => {
  res.status(500);
  res.send("Hello World");
});

// configure routes
app
  .use('/users/', require('./routes/users.js'))
  .use('/api/', require('./routes/api.js'));

  // app.listen(process.env.PORT);
  module.exports.handler = serverless(app);
